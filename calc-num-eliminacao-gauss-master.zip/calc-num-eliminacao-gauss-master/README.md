# calc-num-eliminacao-gauss

Alunos: Carlos Shimomura, Rodrigo Castoldi.
